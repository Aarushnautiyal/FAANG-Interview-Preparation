// Time:  O(n)
// Space: O(1)

class Solution {
public:
    int countPairs(vector<int>& deliciousness) {
        static const int MOD = 1e9 + 7;

        static const auto& floor_log2_x = [](int x) {
            return 8 * sizeof(int) - __builtin_clz(x) - 1;
        };
        
        int max_pow = floor_log2_x(*max_element(cbegin(deliciousness),
                                                cend(deliciousness))) + 1;
        unordered_map<int, int> cnt;
        int result = 0;
        for (const auto& d : deliciousness) {
            int p = 1;
            for (int i = 0; i <= max_pow; ++i) {
                result = (result + cnt[p - d]) % MOD;
                p <<= 1;
            }
            ++cnt[d];
        }
        return result;
    }
};
