// Time:  O(n)
// Space: O(1)

class Solution {
public:
    bool isGoodArray(vector<int>& nums) {
        // Bézout's identity
        int result = nums[0];
        for (const auto& num : nums) {
            result = std::gcd(result, num);  // built-in gcd since C++17, O(logn)
            if (result == 1) {
                break;
            }
        }
        return result == 1;
    }
};
