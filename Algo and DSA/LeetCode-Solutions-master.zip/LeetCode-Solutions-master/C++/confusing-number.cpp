// Time:  O(logn)
// Space: O(logn)

class Solution {
public:
    bool confusingNumber(int N) {
        static const unordered_map<char, char> lookup = 
            {{'0', '0'}, {'1', '1'}, {'6', '9'},
             {'8', '8'}, {'9', '6'}};
 
        const auto& S = to_string(N);
        for (int i = 0; i < S.length(); ++i) {
            if (!lookup.count(S[i])) {
                return false;
            }
        }
        for (int i = 0; i < (S.length() + 1) / 2; ++i) {
            if (S[i] != lookup.at(S[S.length() - 1 - i])) {
                return true;
            }
        }
        return false;
    }
};
